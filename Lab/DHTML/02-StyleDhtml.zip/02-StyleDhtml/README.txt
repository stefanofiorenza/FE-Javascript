Example in 01-SelectorsOnUI.html:


<input id="cssExpression" type="text" placeholder="input Css expression" class="span12" />
<button class="btn dropdown-lead btn-default" onclick="highlightCssExpression()">Highlight Selected</button>

- onclick event is bound to highlightCssExpression in CssSelectorEvaluator.js

ACTIONS:
1) Change the code in CssSelectorEvaluator()
	
	try to trigger different UI changes using style property:
	https://www.w3schools.com/jsref/dom_obj_style.asp