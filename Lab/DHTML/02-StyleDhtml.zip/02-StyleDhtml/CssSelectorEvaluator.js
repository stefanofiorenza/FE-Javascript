
// Change style property value according to 
// https://www.w3schools.com/jsref/dom_obj_style.asp

function highlightCssExpression(){
	let cssExpression =document.getElementById("cssExpression").value;
	let resultNodeSet =document.querySelectorAll(cssExpression);
	for (node of resultNodeSet){
		
		//node.style.backgroundColor = "yellow";
		//node.style.marginLeft = "50px";
		
		/*
		node.style.borderStyle = "solid"
		node.style.borderColor="red"
		node.style.borderWidth="3px"
		*/
	}
}