Example in 01-SelectorsOnUI.html:

<input id="cssExpression" type="text" placeholder="input Css expression" class="span12" />
<button class="btn dropdown-lead btn-default" onclick="highlightCssExpression()">Highlight Selected</button>

- onclick event is bound to highlightCssExpression in CssSelectorEvaluator.js

ACTIONS:
1) Insert different css expression for the selector in UI cssExpression field
2) Click on the button to see selected elements highlighted in yellow
	
try to CSS expression from here:
https://www.w3schools.com/jsref/met_element_queryselectorall.asp

To know more on selectors see also here:
https://javascript.info/searching-elements-dom