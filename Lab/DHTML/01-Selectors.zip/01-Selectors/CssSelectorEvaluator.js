
	function highlightCssExpression(){
		let cssExpression =document.getElementById("cssExpression").value;
		let resultNodeSet =document.querySelectorAll(cssExpression);
		for (node of resultNodeSet){
			node.style.backgroundColor = "yellow";
		}
	}