Example in 01-SelectorsOnUI.html:


<div class="widget-head" onmouseover="testEventAction(this,event)">
	<h4 class="heading">Input controls</h4>
</div>

- onmouseover event is bound to testEventAction in CssSelectorEvaluator.js

ACTIONS:
1) try to bind different events to different elements:
	https://www.w3schools.com/jsref/dom_obj_event.asp
	
2) Change the code in testEventAction()
	
	2.1) trigger some changes in UI (style properties or other)
	2.2) trigger some changes in calling dom node (referenced by this)
	2.3) Use data inside the event object (is ok just to show them in alert or console)